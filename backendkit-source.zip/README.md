# BackendKit

MIT-licensed, browser-local tools and source-linked engineering notes by Hirdyansh Pandey.

## Tools

- CSV import structure checker
- JSON to Pydantic model generator
- Environment variable key comparer
- PostgreSQL error reference helper
- Research blog with a practical MCP security guide

No npm dependencies, AI API keys or backend database are required. Tool inputs are processed in the browser.

## Cloudflare Pages: automatic Git deployments

1. In Cloudflare, open Workers & Pages → Create application → Pages → Import an existing Git repository.
2. Select this repository and authorize access to this repository only.
3. Configure:

| Setting | Value |
| --- | --- |
| Production branch | `main` |
| Framework preset | `None` |
| Build command | `python3 build_cloudflare.py` |
| Build output directory | `dist` |
| Root directory | Repository root |

Save and deploy. Keep automatic production branch deployments enabled. Future pushes to `main` trigger a new deployment. Other branches can produce previews.

`SITE_URL` optionally sets the canonical production URL (for example your custom domain, without a trailing slash). Otherwise Cloudflare's `CF_PAGES_URL` supplies the build URL. After the first deployment, set `SITE_URL` to your production URL for both production and preview environments if previews should canonicalize to production.

Cloudflare Git integration is connected in its dashboard; no Cloudflare API token needs to be stored in GitHub.

## Develop

Python 3, standard library only:

```sh
python3 build_cloudflare.py
python3 -m http.server 8000 --directory dist
```

Edit content and shared layouts in `build.py`; edit tool behavior in `tools.js`. Generated HTML, styles and sitemap are rebuilt by the Python generator. The source ZIP is refreshed during each build.

## Scope

CSV parsing checks structure rather than database types. Generated Pydantic models are sample-based scaffolding. ENV comparison handles one-line assignments. PostgreSQL guidance covers a small curated error set. Blog examples are labeled design exercises rather than verified production findings.

## License

MIT. See LICENSE.
