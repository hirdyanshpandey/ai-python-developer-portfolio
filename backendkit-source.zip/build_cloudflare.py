"""Build the static site and its MIT-licensed downloadable source archive."""
from pathlib import Path
import runpy
import zipfile
root = Path(__file__).resolve().parent
runpy.run_path(str(root / 'build.py'), run_name='__main__')
with zipfile.ZipFile(root / 'dist/backendkit-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in [root/'build.py', root/'build_cloudflare.py', root/'LICENSE', root/'README.md', root/'tools.js', *sorted((root/'dist').rglob('*.html')), root/'dist/style.css', root/'dist/tools.js', root/'dist/robots.txt', root/'dist/sitemap.xml']:
        archive.write(file, file.relative_to(root))
print('Built BackendKit into dist/')
